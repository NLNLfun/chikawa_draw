let answer = ""; // 存答案

// 從後端獲取隨機答案
async function loadAnswer() {
  try {
    const response = await fetch("/api/word"); // 與後端伺服器通訊
    const data = await response.json();
    answer = data.word;
    console.log("答案是：", answer); // 顯示答案以便測試
    initGrid(); // 初始化格子
    initKeyboard(); // 初始化鍵盤
  } catch (error) {
    console.error("無法載入答案，請確認伺服器是否啟動或 API 是否正常：", error);
  }
}

let currentRow = 0;
let currentCol = 0;
let currentGuess = "";

// 初始化遊戲格子
function initGrid() {
  const grid = document.getElementById("grid");
  for (let i = 0; i < 6; i++) {
    for (let j = 0; j < 5; j++) {
      const cell = document.createElement("div");
      cell.classList.add("grid-cell");
      cell.id = `cell-${i}-${j}`;

      // 添加正反面
      const front = document.createElement("div");
      front.classList.add("front");
      const back = document.createElement("div");
      back.classList.add("back");

      cell.appendChild(front);
      cell.appendChild(back);
      grid.appendChild(cell);
    }
  }
}

// 初始化鍵盤
function initKeyboard() {
  const keyboard = document.getElementById("keyboard");
  const row1 = [..."qwertyuiop".split(""), "Del"];
  const row2 = [..."asdfghjkl".split(""), "Enter"];
  const row3 = "zxcvbnm".split("");

  createKeyboardRow(row1, keyboard);
  createKeyboardRow(row2, keyboard);
  createKeyboardRow(row3, keyboard);
}

// 建立鍵盤列
function createKeyboardRow(keys, keyboard) {
  const row = document.createElement("div");
  row.classList.add("keyboard-row");
  keys.forEach((key) => {
    const keyButton = document.createElement("button");
    keyButton.textContent = key;
    keyButton.classList.add("key");
    keyButton.dataset.key = key; // 使用 dataset 屬性便於查找
    keyButton.addEventListener("click", () => handleKeyPress(key));
    row.appendChild(keyButton);
  });
  keyboard.appendChild(row);
}

// 處理按鍵輸入
function handleKeyPress(key) {
  if (key === "Enter") {
    handleEnter(); // 處理提交猜測
  } else if (key === "Del") {
    handleDelete(); // 處理刪除輸入
  } else if (currentCol < 5) {
    const cell = document.getElementById(`cell-${currentRow}-${currentCol}`);
    const front = cell.querySelector(".front");
    front.textContent = key;
    currentGuess += key;
    currentCol++;
  }
}

// 處理提交猜測
function handleEnter() {
  if (currentGuess.length === 5) {
    checkGuess(); // 檢查答案
    currentRow++;
    currentCol = 0;
    currentGuess = "";

    if (currentRow === 6) {
      alert(`遊戲結束！答案是：${answer}`);
    }
  } else {
    alert("單字必須是 5 個字母！");
  }
}

function handleDelete() {
  if (currentCol > 0) {
    currentCol--; // 回到上一列
    const cell = document.getElementById(`cell-${currentRow}-${currentCol}`);
    const front = cell.querySelector(".front");
    front.textContent = ""; // 清空該格子內容
    currentGuess = currentGuess.slice(0, -1); // 移除字母
  }
}

function updateKeyboard(letter, state) {
  const keyButton = document.querySelector(`.key[data-key='${letter}']`);

  if (keyButton) {
    if (state === "correct") {
      keyButton.classList.add("correct");
    } else if (state === "present") {
      if (!keyButton.classList.contains("correct")) {
        keyButton.classList.add("present");
      }
    } else if (state === "absent") {
      if (!keyButton.classList.contains("correct") && !keyButton.classList.contains("present")) {
        keyButton.classList.add("absent");
      }
    }
  }
}

function checkGuess() {
  const guess = currentGuess.split("");
  const answerArray = answer.split("");

  guess.forEach((letter, index) => {
    const cell = document.querySelector(`#grid .grid-cell:nth-child(${currentRow * 5 + index + 1})`);
    const back = cell.querySelector(".back");

    back.textContent = letter; // 更新背面內容

    if (letter === answerArray[index]) {
      back.style.backgroundColor = "#6aaa64"; // 綠色
      updateKeyboard(letter, "correct"); // 鍵盤設置為正確
    } else if (answerArray.includes(letter)) {
      back.style.backgroundColor = "#c9b458"; // 黃色
      updateKeyboard(letter, "present"); // 鍵盤設置為部分正確
    } else {
      back.style.backgroundColor = "#808080"; // 灰色
      updateKeyboard(letter, "absent"); // 鍵盤設置為不存在
    }

    cell.classList.add("flip"); // 添加翻轉效果
  });
}


// 載入答案並初始化遊戲
loadAnswer();
