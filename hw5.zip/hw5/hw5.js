const fs = require("fs"); // Node.js 的檔案系統模組
const express = require("express"); // 輕量化的伺服器框架
const path = require("path");

// 創建 Express 應用程式
const app = express();

// 設定靜態檔案資料夾，提供 HTML、CSS 和前端 JS 檔案
app.use(express.static(path.join(__dirname)));

// 讀取字典檔案，並過濾出 5 個字母的單字
let words = [];
let answer = "";

function loadWords() {
  try {
    const text = fs.readFileSync("dictionary.txt", "utf-8");
    words = text
      .split("\n")
      .map((word) => word.trim())
      .filter((word) => word.length === 5);

    if (words.length === 0) {
      throw new Error("No valid words found in dictionary.txt");
    }

    answer = words[Math.floor(Math.random() * words.length)];
    console.log("遊戲已初始化，答案是：", answer);
  } catch (error) {
    console.error("讀取字典檔案時發生錯誤：", error.message);
  }
}

// 初始化字典
loadWords();

// 提供根路徑，返回 hw5.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "hw5.html"));
});

// 提供 API 端點，返回隨機答案（前端用來初始化遊戲）
app.get("/api/word", (req, res) => {
  res.json({ word: answer });
});

// 啟動伺服器
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`伺服器已啟動：http://localhost:${PORT}`);
});



